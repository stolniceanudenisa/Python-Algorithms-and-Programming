

class Client:
    id = 0
    def __init__(self, nume, prenume, comanda):
        self.__id = id
        self.__nume = nume
        self.__prenume = prenume
        self.__comanda = comanda
        Client.id += 1

    def getNume(self):
        return self.__nume
    
    def getPrenume(self):
        return self.__prenume

    def getComanda(self):
        return self.__comanda

    def setNume(self, nume):
        self.__nume = nume

    def setPrenume(self, prenume):
        self.__prenume = prenume
    
    def setComanda(self, comanda):
        self.__comanda = comanda

    def getId(self):
        return self.__id
    
    def setId(self, idNou):
        self.__id = idNou
    
    def __str__(self):
        return "Clientul: " + self.__nume +" "+ self.__prenume + " a comandat: " + self.__comanda.__str__()

    