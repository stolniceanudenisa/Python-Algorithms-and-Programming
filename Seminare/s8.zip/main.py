from repository.client_repository import ClientRepository
from util.util import *

from repository.haine_repository import *

if __name__ == "__main__":
    haina = Haine("rochie", "M", "rosu", 1000)
    hr = HaineRepository()
    hr.save(haina)
    print(hr.__str__())

    haina2 = Haine("rochie", "S", "rosu", 1000)
    hr.save(haina2)
    hr.updateHaine(haina.getId(), ["produs","bluza"])
    print(hr.__str__())

    hr.deleteHaine(haina.getId())
    print(hr.__str__())

    haina3 = Haine("pantaloni", "S", "verde", 100)

    client1 = Client("Mocan", "Roxana", Comanda([haina, haina2]))
    client2 = Client("Avram", "Adina", Comanda([haina2, haina3, haina3]))
    client3 = Client("Andries", "Laura", Comanda([haina, haina3, haina3]))
    print(client1.getComanda().getSumaTotala())
    print(client2.getComanda().getSumaTotala())
    cr = ClientRepository()
    cr.save(client1)
    cr.save(client2)
    cr.save(client3)
    print(cr.__str__())
    cr.sortByNameAndSum()
    print("sort by name and sum")
    print(cr.__str__())



