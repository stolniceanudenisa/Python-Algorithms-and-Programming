from domain.client import *
class ClientRepository:
    def __init__(self):
        self.__allClients = []

    def getAllClients(self):
        return self.__allClients

    def __findClientByName(self,nume, prenume):
        for cl in self.__allClients:
            if cl.getNume() == nume and cl.getPrenume() == prenume:
                return True
        return False
    def save(self, client):
        if self.__findClientByName(client.getNume(), client.getPrenume()) == True:
            raise ValueError ("Client Duplicat")
        self.__allClients.append(client)

    def __findCleintById(self,id):
        for cl in self.__allClients:
            if cl.getId() == id:
                return True
        return False

    def update(self, id, comanda):
        if self.__findCleintById(id) == True:
            self.__allClients[id].setComanda(comanda)
        else:
            raise ValueError("Id-ul nu exista")

    def delete(self,id):
        if self.__findCleintById(id) == True:
            del self.__allClients[id]
            self.refreshIds()
        else:
            raise ValueError("Id-ul nu exista")


    def refreshIds(self):
        for idx in range(0,len(self.__allClients)):
            self.__allClients[idx].setId(idx)
        Client.id = len(self.__allClients)   

    def sortByNameAndSum(self):
        nameList = []
        sortedList = []
        for i in self.__allClients:
            nameList.append(i.getNume())
        nameList.sort()

        for i in nameList:
            for j in self.__allClients:
                if i == j.getNume() and j.getComanda().getSumaTotala() < 2000:
                    sortedList.append(j)
                    break
        self.__allClients = sortedList

    def __str__(self):
        string = ""
        for c in self.__allClients:
            string += c.__str__() + "\n"
        return string