from domain.haine import *


class HaineRepository:
    def __init__(self):
        self.__all_haine = []


    def __find_by_id(self, id):
        for haina in self.__all_haine:
            if haina.getId() == id:
                return True
        return False

    def save(self, haina):
        if self.__find_by_id(haina.getId()) == True:
                raise ValueError("Duplicate id")
        self.__all_haine.append(haina)

    def getAllHaine(self):
        return self.__all_haine

    def updateHaine(self, id, atribut):
        if self.__find_by_id(id) == True:
            if atribut[0] == "produs":
                self.__all_haine[id].setProdus(atribut[1])
            elif atribut[0] == "marime":
                self.__all_haine[id].setMarime(atribut[1])
            elif atribut[0] == "culoare":
                self.__all_haine[id].setCuloare(atribut[1])
            elif atribut[0] == "pret":
                self.__all_haine[id].setPret(atribut[1])
            else:
                raise ValueError("Haina nu are acest atribut")   
            
        else:
            raise ValueError("Nu exista acest id")

    def refreshIds(self):
        for idx in range(0,len(self.__all_haine)):
            self.__all_haine[idx].setId(idx)
        Haine.id = len(self.__all_haine)


    def deleteHaine(self, id):
        del self.__all_haine[id]
        self.refreshIds()

    def __str__(self):
        str = ""
        for h in self.__all_haine:
            str += h.__str__() + "\n"
        return str
        

    

