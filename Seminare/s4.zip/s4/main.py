from tests.testSimpleComputations import *
from tests.testListComputations import *
from ui.ui import *
from calculator.simpleComputations import addNumbers, substractNumbers
from calculator.listComputations import *

if __name__ == "__main__":
    testSimpleComputations()
    testListComputations()
    opt = options()
    if opt == 1:
        a = read_number()
        b = read_number()
        sum = addNumbers(a,b)
        diff = substractNumbers(a,b)
        writeResult(sum)
        writeResult(diff)
    elif opt == 2:
        list = readList()
        b = read_number()
        list = addItem(list,b)
        writeResult(list)
        c = read_number()
        list = removeItem(list, c)
        writeResult(list)


    