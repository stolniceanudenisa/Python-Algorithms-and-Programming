def addNumbers(a, b):
    # make sum of given numbers
    # input: a, b - natural numers
    # output: sum - natural number
    sum = a + b
    return sum

def substractNumbers(a, b):
    # difference between two numbers
    # input: a, b - natural numbers
    # output: substraction - natural number
    if a > b:
        return a - b
    elif b > a:
        return b - a
    else:
        return 0


