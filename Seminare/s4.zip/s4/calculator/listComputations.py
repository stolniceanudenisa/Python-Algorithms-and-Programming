def addItem(list, number):
    # add a number in list, if does not exits
    # input: list, number to be added
    # output list including the number
    if number in list:
        return list
    else:
        list.append(number)
        return list 

def removeItem(list, number):
    if number in list:
        list.remove(number)
    return list

def changeItem(list, position, newNumber):
    # change a number at specific position
    # input: list, position new number-natural number
    # output: list with position changed
    if len(list) > position:
        list[position] = newNumber
    return list