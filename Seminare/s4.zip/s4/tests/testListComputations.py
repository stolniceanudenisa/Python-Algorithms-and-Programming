from calculator.listComputations import *

def testAddItem():
    assert addItem([], 1) == [1]
    assert addItem([1,2],2) == [1,2]
    assert addItem([1,2],3) == [1,2,3]
    assert addItem([1,2],"a") == [1,2,"a"]

def testRemoveItem():
    assert removeItem([],1) == []
    assert removeItem([1],1) == []
    assert removeItem([2],1) == [2]
    assert removeItem(["a"], 1) == ["a"]
    assert removeItem(["a"], "a") == []

def testchangeItem():
    assert changeItem([1,2,4],2,3) == [1,2,3]
    assert changeItem([1,2,4],5,5) == [1,2,4]
    assert changeItem([],2,3) == []
    assert changeItem([1,2,3],0,5) == [5,2,3]
    assert changeItem([1,2,3], -1, 5) == [1,2,5]

def testListComputations():
    testAddItem()
    testRemoveItem()
    testchangeItem()
    print("All list computation test are ok")

