from calculator.simpleComputations import *

def testAddNumbers():
    assert addNumbers(0,1) == 1
    assert addNumbers(1,1) == 2
    assert addNumbers(2,5) == 7
    assert addNumbers(0,0) == 0
    assert addNumbers(-1,2) == 1

def testDifference():
    assert substractNumbers(0,1) == 1
    assert substractNumbers(1,1) == 0
    assert substractNumbers(2,5) == 3
    assert substractNumbers(0,0) == 0
    assert substractNumbers(-1,2) == 3
    assert substractNumbers(-1,-2) == 1

def testSimpleComputations():
    testAddNumbers()
    testDifference()
    print("All simpleCoputation tests are ok")