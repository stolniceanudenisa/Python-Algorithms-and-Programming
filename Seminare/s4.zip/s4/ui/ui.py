from os import replace


def read_number():
    #read number from console
    #input -
    #output - integer number
    number = int(input("Give me the number: "))
    return number

def writeResult(result):
    #print result given as parameter
    #input: result
    #output: -
    print("Result is:", result)

def readList():
    # get from console a list of integers
    # input: list as string
    # output: list of integer
    inList = input("Give me the list")
    if "[" in inList:
        inList = inList.replace("[","")
    if "]" in inList:
        inList = inList.replace("]","")
    if "," in inList:
        inList = inList.split(",")
    list = []
    for l in inList:
        list.append(int(l))
    return list

def options():
    opt = int(input("1: perform simple computations, \n2: perform list computations"))
    return opt

