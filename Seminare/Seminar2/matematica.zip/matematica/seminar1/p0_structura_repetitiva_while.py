'''
Structura repetitiva while
'''


'''
O structura repetitiva de tip while are forma urmatoare

while conditie:
    instructiune1
    instructiune2
    ...


Structura while este o structura repetitiva. Tinem minte ca while inseamna CAT TIMP.
Ea functioneaza ca si un if, doar ca repeta instructiunile din interiorul ei (cele aliniate mai la dreapta) CAT TIMP conditia este adevarata.
Daca conditia este falsa de la inceput, instructiunile din interiorul while-ului nu se executa NICIODATA.
Daca conditia este mereu adevarata, se va crea o bucla infinita, iar codul din interiorul while-ului NU SE VA OPRI niciodata din executat.

Instructiunile instructiune1 si instructiune2 sunt in interiorul structurii repetitive while.
Observati ca sunt aliniate mai la dreapta.
'''

i = 0
while i < 5:
    print("acum i este", i)
    i = i + 1

print("la finalul while-ului, i are valoarea", i)

'''
In exemplul de mai sus, observam ca conditia din while este i < 5.
Asta inseamna ca instructiunile din interiorul while-ului (cele aliniate mai la dreapta) se vor executa CAT TIMP i < 5
In interiorul while-ului avem instructiunea i = i + 1 (valoarea lui i creste cu 1). Aceasta instructiune este FOARTE IMPORTANTA.
Datorita acestei instructiuni, i (care este initial 0) devine 1 dupa prima executie a instructiunilor din while.
Dupa a doua executie i devine 2. Dupa a treia executie i devine 3, ... Si tot asa, pana devine 5.
Cand i devine 5, conditia i < 5 din while devine falsa, deoarece i este 5, iar 5 nu e < 5. Datorita acestui lucru putem sa oprim repetarea la infinit a while-ului si iesim din while
Atunci mergem mai departe la urmatoarele instructiuni din program.
Observati ca instructiunea print("la finalul while-ului, i are valoarea", i) NU mai este aliniata la dreapta fata de while.
Inseamna ca aceasta instructiune este in afara while-ului. Deci aceasta instructiune va fi executata o singura data.  
'''

'''
Exemplu in care conditia din while este falsa de la inceput. Instructiunile din while nu se vor executa niciodata 
'''
x = 1
while x < 0:
    print("Acest mesaj nu se va tipari niciodata in consola, pentru ca programul nu executa aceasta instructiune")
print("Am trecut de while")

'''
Exemplu in care conditia din while este mereu adevarata. 
Se va crea o bucla infinita si executia instructiunilor din while nu se va opri niciodata.
Decomentati codul si rulati ca sa observati ce se intampla.
'''
#numar = 10
#while numar == 10:
#    print("Asta se tipareste la infinit")
#print("Executia nu ajunge niciodata aici")