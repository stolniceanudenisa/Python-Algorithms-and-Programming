'''
Calculati primele k numere prime dupa numarul n dat.
'''
n = int(input("Introduceti numarul n: "))
k = int(input("Introduceti numarul k: "))


def este_prim(n):
    '''
    Verifica daca un numar dat este prim.
    Date intrare: n (numarul dat)
    Date iesire: True, daca n este prim
                 False, altfel
    '''
    prim = True
    if n == 0 or n == 1:
        prim = False
    else:
        for i in range(2, n//2+1):
            if n % i == 0:
                prim = False
    return prim


urmatorul_numar = n + 1

numere_prime_gasite = 0

#cat timp numarul de numere prime gasite este mai mic decat valoarea lui k
while numere_prime_gasite < k:
    #daca numarul este prim (adica: daca functia este_prim returneaza valoarea True pentru urmatorul_numar)
    if este_prim(urmatorul_numar) == True:
        print("A fost gasit numarul prim", urmatorul_numar) #inseamna ca am mai gasit un numar prim si il tiparim in consola
        numere_prime_gasite = numere_prime_gasite + 1 #de asemenea, crestem numarul de numere prime gasite cu 1
    urmatorul_numar = urmatorul_numar + 1 #mergem la numarul urmator
