'''
Calculati varsta unei persoane in zile.
Asadar, daca data nasterii persoanei si data curenta sunt date in forma: ZZ LL AAAA
Calculati numarul de zile dintre cele doua date. Se va tine cont de anii bisecti.
'''

#Persoana
print("Datele persoanei")
zi_persoana = int(input("Zi persoana: "))
luna_persoana = int(input("Luna persoana: "))
an_persoana = int(input("An persoana: "))

#Data curenta
print("Data curenta")
zi_curenta = int(input("Zi curenta: "))
luna_curenta = int(input("Luna curenta: "))
an_curent = int(input("An curent: "))

'''
Cum vom proceda?
1. Calculam numarul de zile de la data nasterii persoanei pana la sfarsitul anului in care s-a nascut persoana
2. Calculam numarul de zile de la inceputul anului curent pana la data curenta
3. Calculam numarul de zile pentru anii intregi care au ramas, tinand cont de anii bisecti
'''


def calculeaza_zile_pana_la_sfarsitul_anului(zi, luna, an):
    '''
    Calculeaza numarul de zile de la o anumita data pana la sfarsitul anului.
    Ex.: Daca pentru parametrii (zi,luna,an) introducem (2,11,2022), algoritmul va returna numarul de zile din data de 2.11.2022 pana la sfarsitul anului 2022
    Date intrare: zi
                  luna
                  an
    Date iesire: zile_pana_la_sfarsitul_anului
    '''
    if luna == 1:
        if an % 4 == 0:
            zile_pana_la_sfarsitul_anului = 366
        else:
            zile_pana_la_sfarsitul_anului = 365
    elif luna == 2:
        if an % 4 == 0:
            zile_pana_la_sfarsitul_anului = 366 - 31
        else:
            zile_pana_la_sfarsitul_anului = 365 - 31
    elif luna == 3:
        zile_pana_la_sfarsitul_anului = 31 + 30 + 31 + 30 + 31 + 31 + 30 + 31 + 30 + 31
    elif luna == 4:
        zile_pana_la_sfarsitul_anului = 30 + 31 + 30 + 31 + 31 + 30 + 31 + 30 + 31
    elif luna == 5:
        zile_pana_la_sfarsitul_anului = 31 + 30 + 31 + 31 + 30 + 31 + 30 + 31
    elif luna == 6:
        zile_pana_la_sfarsitul_anului = 30 + 31 + 31 + 30 + 31 + 30 + 31
    elif luna == 7:
        zile_pana_la_sfarsitul_anului = 31 + 31 + 30 + 31 + 30 + 31
    elif luna == 8:
        zile_pana_la_sfarsitul_anului = 31 + 30 + 31 + 30 + 31
    elif luna == 9:
        zile_pana_la_sfarsitul_anului = 30 + 31 + 30 + 31
    elif luna == 10:
        zile_pana_la_sfarsitul_anului = 31 + 30 + 31
    elif luna == 11:
        zile_pana_la_sfarsitul_anului = 30 + 31
    else:
        zile_pana_la_sfarsitul_anului = 31

    zile_pana_la_sfarsitul_anului = zile_pana_la_sfarsitul_anului - zi
    return zile_pana_la_sfarsitul_anului


def calculeaza_zile_de_la_inceputul_anului(zi, luna, an):
    '''
    Calculeaza numarul de zile de la inceputul anului pana la o anumita data.
    Ex.: daca pentru parametrii (zi,luna,an) dam valorile (2,11,2022), algoritmul va returna numarul de zile de la inceputul anului 2022 pana in 2.11.2022
    Date intrare: zi
                  luna
                  an
    Date iesire: zile_de_la_inceputul_anului
    '''

    #nr de zile de la inceputul anului pana la o anumita data = cu nr de zile din an - nr de zile de la acea data la sfarsitul anului
    #noi am scris deja functia calculeaza_zile_pana_la_sfarsitul_anului care, daca primeste ca parametri o zi, o luna si un an, calculeaza cate zile sunt de la acea data pana la sfarsitul anului
    zile_pana_la_sfarsitul_anului = calculeaza_zile_pana_la_sfarsitul_anului(zi, luna, an)

    #acum va trebui doar sa scadem din numarul total de zile din an valoarea variabilei zile_pana_la_sfarsitul_anului

    #daca anul este bisect, totalul de zile este 366, altfel este 365
    #pentru a afla numarul de zile de la inceputul anului pana la data pe care am introdus-o,
    #scadem din numarul total de zile din an, numarul de zile ramase in an
    if an % 4 == 0:
        zile_de_la_inceputul_anului = 366 - zile_pana_la_sfarsitul_anului
    else:
        zile_de_la_inceputul_anului = 365 - zile_pana_la_sfarsitul_anului
    return zile_de_la_inceputul_anului


def calculeaza_numarul_de_zile_al_anilor_intregi_ramasi(an_inceput, an_sfarsit):
    '''
    Calculeaza numarul de zile intre 2 ani dati (excluzand acei ani).
    Ex.: daca parametrii sunt 1990 si 1998, se calculeaza numarul de zile total al anilor 1991, 1992, ..., 1997.
    Date intrare: an_inceput
                  an_sfarsit
    Date iesire: suma (suma zilelor dintre acesti ani)
    '''
    suma = 0
    for i in range(an_inceput + 1, an_sfarsit):
        if i % 4 == 0:
            suma = suma + 366
        else:
            suma = suma + 365
    return suma


nr_zile_pana_la_finalul_anului_nasterii = calculeaza_zile_pana_la_sfarsitul_anului(zi_persoana, luna_persoana, an_persoana)
nr_zile_de_la_inceputul_anului_curent = calculeaza_zile_de_la_inceputul_anului(zi_curenta, luna_curenta, an_curent)
nr_zile_ani_intregi_ramasi = calculeaza_numarul_de_zile_al_anilor_intregi_ramasi(an_persoana, an_curent)

nr_total_zile = nr_zile_pana_la_finalul_anului_nasterii + nr_zile_de_la_inceputul_anului_curent + nr_zile_ani_intregi_ramasi
print("Numarul total de zile este: ", nr_total_zile)