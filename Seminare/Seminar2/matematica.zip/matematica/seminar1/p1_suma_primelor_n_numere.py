"""
Calculati suma primelor n numere naturale.
"""

#citim nurmarul n de la tastatura
n = int(input("Introduceti valoarea lui n: "))

#folosim formula lui Gauss pentru calculul sumei
suma = n*(n+1)//2

#tiparim rezultatul in consola
print("Suma este ", suma)