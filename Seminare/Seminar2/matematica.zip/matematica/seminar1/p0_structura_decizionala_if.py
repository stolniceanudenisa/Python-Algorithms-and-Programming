'''
Structura decizionala if
'''

'''
O structura decizionala de tip if are forma urmatoare

if conditie:
    instructiune1
    instructiune2
    ...

Structura if ne permite sa executam un set de instructiuni doar atunci cand o conditie este indeplinita.
Instructiunile instructiune1 si instructiune2 sunt in interiorul structurii decizionale if si vor fi executate numai atunci cand conditia este indeplinita.
Observati ca sunt aliniate mai la dreapta.
Aceste instructiuni se vor executa DOAR DACA conditia din if este adevarata.
'''

x = 0 #folosim un singur = cand ATRIBUIM o valoare unei variabile (aici atribuim valoarea 0 variabilei x)
if x == 0: #folosim == cand suntem intr-o structura cum ar fi if (sau while) si VERIFICAM daca o variabila are o anumita valoare (aici verificam daca variabila x are valoarea 0)
    print("Instructiunile sunt aliniate mai la dreapta, deci suntem in interiorul if-ului.")
    print("x este = cu 0")
print("Am iesit din if, aceasta instructiune este executata oricum.")
print("Observati ca aceasta instructiune nu mai este aliniata la dreapta.")


'''
Dam valori variabilelor a si b
Puteti modifica valorile lui a si b (incercati sa le dati aceeasi valoare, sau sa dati lui a o valoare mai mare decat b)
'''
a = 4
b = 5

'''
Vrem sa tiparim un mesaj in consola care sa ne spuna ce relatie este intre a si b
Nu este obligatoriu, dar structura decizionala if mai poate avea inca o ramura, anume cea de else
Tinem minte ca if inseamna DACA, iar else inseamna ALTFEL
Se va intra DOAR pe ramura structurii decizionale if a carei conditie este adevarata
Deci, intr-o structura de tip if-else se intra DOAR PE O SINGURA RAMURA
Daca este adevarat ca a < b, atunci se va executa ce este in ramura corespunzatoare lui if a < b:
Altfel, se va executa ce este in ramura corespunzatoare lui else:
'''
if a < b:
    print("a este mai mic decat b")
else:
    print("a este mai mare sau egal cu b")
print("Aceasta este o instructiune dupa primul if")

'''
O structura decizionala de tip if poate sa aiba mai multe ramuri, nu doar ramura de if si cea de else
Vedeti ca intre if si else am mai adaugat doua ramuri de elif
Este foarte important ca ramura (sau ramurile) de elif sa fie intre ramura de if si cea de else, aceasta este ordinea corecta
elif vine de la "else if", care tradus inseamna ALTFEL DACA
Din nou, se va intra pe o singura ramura a structurii decizionale if, si anume PE PRIMA a carei conditii este adevarata
Pentru a = 4 si b = 5, conditia din ramura A DOUA: elif a != b (a e diferit de b) este adevarata
Dar pentru ca a < b, conditia pusa pe PRIMA ramura, este si ea adevarata, se va executa doar codul PRIMEI ramuri cu conditia adevarata
'''
if a < b:
    print("a este mai mic decat b")
    print("Se executa doar codul primei ramuri cu conditia adevarata")
elif a != b:
    print("a este diferit de b")
elif a == b:
    print("a este egal cu b")
else:
    print("a este mai mare sau egal cu b")
