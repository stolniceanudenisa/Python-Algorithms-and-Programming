#putem atribui unei variabile o valoare atunci cand scriem programul, de exemplu:
mesaj = "un mesaj"

#sau putem atribui unei variabile o valoare atunci cand executam programul
#pentru asta, vom folosi citirea de la tastatura

#citim de la tastatura un text
#variabile sir_de_caractere primeste ca valoare textul citit
sir_de_caractere = input("Scrieti un text aici si apasati Enter: ")
print("Textul introdus este", sir_de_caractere)

#citim de la tastatura un numar
numar = int(input("Acum introduceti un numar si din nou apasati Enter: "))
print("Numarul introdus este", numar)