from Animal import *

class Pisica(Animal):
    pass