from Animal import *
class Caine(Animal):
    def __init__(self, invelis, mancare, sunet, joaca):
        super().__init__(invelis,mancare,sunet)
        self.__joaca = joaca

    def getJoaca(self):
        return self.__joaca

    def setJoaca(self, joaca):
        self.__joaca = joaca

    def __str__(self):
        return "Cainele are " + self.getInvelis() +" mananca "+ self.getMancare() +" scoate un "+ self.getSunet() +" si se joaca cu "+ self.getJoaca()

