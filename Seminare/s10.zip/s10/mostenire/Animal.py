class Animal:
    def __init__(self, invelis, mancare, sunet):
        self.__invelis = invelis
        self.__mancare = mancare
        self.__sunet = sunet
    
    def setInvelis(self, invelis):
        self.__invelis = invelis

    def setMancare(self, mancare):
        self.__mancare = mancare

    def setSunet(self,sunet):
        self.__sunet = sunet

    def getInvelis(self):
        return self.__invelis

    def getMancare(self):
        return self.__mancare
    
    def getSunet(self):
        return self.__sunet

    def __str__(self):
        return "Animalul are " + self.getInvelis() +" mananca "+ self.getMancare() +" scoate un "+ self.getSunet() 
