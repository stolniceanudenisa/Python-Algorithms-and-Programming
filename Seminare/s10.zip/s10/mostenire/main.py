from Caine import *
from Pisica import *


if __name__ == "__main__":
    pisica  =  Pisica("blana", "lapte", "mieunat")
    caine = Caine("blana", "carne", "latrat", "osul")
    print(str(pisica))
    print(str(caine))