#lungimea unei liste fara sa folosim len(lista)

def lungime(lista):
    if lista != []:
        return 1 + lungime(lista[1:])
    return 0

# suma elementelor dintro lista
def suma(lista):
    if lista != []:
        return lista[0] + sum(lista[1:])
    return 0

# cmmdc Euclid
def cmmdc(a,b):
    if ( b == 0):
        return a
    return cmmdc(b,a%b)
    
# cmmdc in lista
def cmmdc_l(lista):
    min = max(lista)
    for i in range(0,lungime(lista)-1):
        c = cmmdc(lista[i],lista[i+1])
        if min > c:   
            min = c
    return min

# factorialul unui nr
def factorial(x):
    if x == 1:
        return 1
    return x * factorial(x-1)

if __name__ == "__main__":
    lista = [55,25,30,45]
    lungimea_listei = lungime(lista)
    print("Lungimea listei e: ", lungimea_listei)
    suma_listei = suma(lista)
    print("Suma listei e: ", suma_listei)
    cmmdc_elemente = cmmdc(20,15)
    print("Cmmdc dintre doua elemente",cmmdc_elemente)
    cmmdc_lista = cmmdc_l(lista)
    print("Cmmdc din lista e ", cmmdc_lista)
    nr = 5
    fac = factorial(nr)
    print(str(nr) +"! = ", fac)