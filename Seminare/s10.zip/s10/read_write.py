from haine import *

def read(path):
    lista_haine = []
    with open(path) as f:
        for line in f:
            line_split = line.split(";")
            produs = line_split[0]
            marime = line_split[1]
            culoare = line_split[2]
            pret = line_split[3]
            haina = Haine(produs,marime,culoare,pret)
            lista_haine.append(haina)
    return lista_haine


def afisareHaine(lista_haine):
    for haina in lista_haine:
        print(str(haina))

def write(path, haina):
    # pt write puteti folosi "w" (=write) sa suprascrie, "a"(=append) ca adauge la ce e scris
    with open(path,"a") as f:
        line = haina.getProdus()+";"+haina.getMarime()+";"+haina.getCuloare()+";"+str(haina.getPret())
        f.write(line)
        f.write("\n")
        

if __name__=="__main__":
    path_to_txt = "haine.txt"
    lista_haine = read(path_to_txt)
    afisareHaine(lista_haine)
    haina = Haine("vesta","gri","S","70")
    write(path_to_txt,haina)

    


