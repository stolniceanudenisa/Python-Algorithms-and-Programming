from domain.client import *
from domain.comanda import *
from domain.magazin import *

def makeListaHaine():
    rochie1 = Haine("rochie", "M", "rosie", 300)
    rochie2 = Haine("rochie", "S", "rosie", 300)
    rochie3 = Haine("rochie", "M", "verde", 350)
    bluza1 = Haine("bluza", "M", "negru", 100)
    bluza2 = Haine("bluza", "S", "gri", 100)

    comanda1 = Comanda([rochie1, rochie2])
    comanda2 = Comanda([rochie2, rochie3])

    client1 = Client("Popescu", "Andreea", comanda1)
    client2 = Client("Dumitru", "Georgiana", comanda2)
    print(client1.getComanda().getSumaTotala())
    print(client2.getComanda().getSumaTotala())

    magazin = Magazin([client1, client2], [rochie1, rochie2, rochie3])

    lista_haine_categorie = magazin.getCategorieHaine("rochie")
    for l in lista_haine_categorie:
        print(l.__str__())
