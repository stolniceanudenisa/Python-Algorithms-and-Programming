

class Client:
    def __init__(self, nume, prenume, comanda):
        self.__nume = nume
        self.__prenume = prenume
        self.__comanda = comanda

    def getNume(self):
        return self.__nume
    
    def getPrenume(self):
        return self.__prenume

    def getComanda(self):
        return self.__comanda

    def setNume(self, nume):
        self.__nume = nume

    def setPrenume(self, prenume):
        self.__prenume = prenume
    
    def setComanda(self, comanda):
        self.__comanda = comanda
    
    def __str__(self):
        return "Clientul: " + self.__nume + self.__prenume + " a comandat: " + self.__comanda

    