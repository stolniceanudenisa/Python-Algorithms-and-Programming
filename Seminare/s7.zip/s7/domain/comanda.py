
class Comanda:
    def __init__(self, listaHaine=[]):
        self.__listaHaine = listaHaine
    
    def getListaHaine(self):
        return self.__listaHaine

    def setListaHaine(self,listahaine):
        self.__listaHaine = listahaine

    def getHaina(self, index):
        if self.__listaHaine > index:
            return self.__listaHaine[index]
        else: 
            return "Nu se gaseste in lista aceasta haina"

    def getSumaTotala(self):
        suma = 0
        for i in self.__listaHaine:
            suma += i.getPret()
        return suma
        
            
    