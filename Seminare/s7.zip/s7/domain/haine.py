

class Haine:

    def __init__(self, produs, marime, culoare, pret):
        self.__produs =  produs
        self.__marime = marime
        self.__culoare = culoare
        self.__pret = pret

    def getProdus(self):
        return self.__produs

    def getMarime(self):
        return self.__marime

    def getCuloare(self):
        return self.__culoare

    def getPret(self):
        return self.__pret

    def setProdus(self, produs):
        self.__produs = produs

    def __str__(self):
        return "Produsul " + self.__produs + " are marimea " + self.__marime + " , culoarea " + self.__culoare + " si pretul " + str(self.__pret)