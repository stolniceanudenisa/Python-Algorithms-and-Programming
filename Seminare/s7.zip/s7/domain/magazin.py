from domain.client import *
from domain.haine import *
from domain.comanda import *

class Magazin:
    def __init__(self, lista_clienti=[], lista_haine = []):
        self.__lista_clienti = lista_clienti
        self.__lista_haine = lista_haine

    def getTotiClientii(self):
        return self.__lista_clienti

    def getToateHainele(self):
        return self.__lista_haine

    def getCategorieHaine(self, categorie):
        lista_categorie = []
        for i in self.__lista_haine:
            if i.getProdus() == categorie:
                lista_categorie.append(i)
        return lista_categorie

    def getNumarProduse(self):
        return len(self.__lista_haine)

    def getNumarClienti(self):
        return len(self.__lista_clienti)




    