'''
Gasiti primul numar prim mai mare decat un numar n dat.
'''

#citim numarul n de la tastatura
n = int(input("Introduceti numarul n: "))

'''
Aceasta este o functie. Functia se numeste este_prim. Codul este exact cel pe care l-am folosit la Problema 2.
Observati ca o functie se introduce folosind cuvantul def
Functia este_prim primeste un parametru, si anume numarul pe care il vom verifica daca este prim
Functia este_prim returneaza valoarea variabilei prim (True, daca parametrul primit este prim sau False, daca nu este prim)
Mai multe informatii despre functii gasiti in fisierul functii.py
'''
def este_prim(n):
    prim = True
    if n == 0 or n == 1:
        prim = False
    else:
        for i in range(2, n//2+1):
            if n % i == 0:
                prim = False
    return prim

#urmatorul numar dupa numarul n citit este n+1
urmatorul_numar = n + 1

#apelam functia este_prim pentru urmatorul_numar
#cat timp urmatorul_numar nu este prim, mergem la numarul urmator
while este_prim(urmatorul_numar) != True:
    urmatorul_numar = urmatorul_numar + 1

#se iese din structura repetitiva while cand functia este_prim(urmatorul_numar) returneaza valoarea True
#deci acum variabila urmatorul_numar contine valoarea urmatorului numar prim mai mare decat numarul n dat
print("Urmatorul numar prim dupa", n, "este", urmatorul_numar)