"""
Verificati daca un numar citit de la tastatura este prim.
"""

#citim numarul de la tastatura
nr = int(input("Introduceti numarul pe care doriti sa il verificati: "))

#presupunem initial ca numarul este prim
#daca vom gasi vreun divizor, vom schimba valoarea lui prim in False
prim = True

#0 si 1 nu sunt numere prime, deci daca numarul e 0 sau 1 valoarea variabilei prim va deveni False
if nr == 0 or nr == 1:
    prim = False
else:
    #suntem in else, deci inseamna ca nr este mai mare decat 1
    #parcurgem folosind i toate numerele de la 2 la nr//2 (jumatatea lui nr) ca sa cautam divizori
    for i in range(2, nr//2+1):
        #daca restul impartirii lui nr la i este 0, inseamna ca i este un divizor la lui nr
        if nr % i == 0:
            #daca am gasit un divizor, valoarea variabilei prim va deveni False
            prim = False

#la final verificam valoarea variabilei prim, si in functie de aceasta ne dam seama daca numarul este prim sau nu
#daca valoarea lui prim este True, inseamna ca nu am gasit divizori, deci numarul este prim
#altfel (daca valoarea lui prim este False), inseamna ca am gasit cel putin un divizor, deci numarul nu este prim
if prim == True:
    print("Numarul este prim.")
else:
    print("Numarul nu este prim.")