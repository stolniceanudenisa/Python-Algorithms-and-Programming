"""
Calculati cel mai mare divizor comun a doua numere.
"""

#citim numerele a si b de la tastatura
a = int(input("Introduceti primul numar:"))
b = int(input("Introduceti al doilea numar:"))

#folosim algoritmul de determinare al cmmdc-ului prin scaderi repetate
while a != b:
    if a > b:
        a = a - b
    else:
        b = b - a

#structura repetitiva while se va executa atata timp cat a este diferit de b (a != b)
#atunci cand a devine egal cu b, se iese din while
#tiparim in consola rezultatul obtinut
print("cmmdc este", a)