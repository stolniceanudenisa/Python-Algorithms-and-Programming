'''
FUNCTII
'''


'''
O functie este un bloc de cod care poate fi reutilizat

O functie trebuie sa faca un singur lucru, pentru a putea fi reutilizata in program (Principiul Responsabilitatii Unice)
Nu facem citiri in functii (decat daca functiile sunt destinare exclusiv citirii)
Nu tiparim in functii (decat daca functiile sunt destinate exclusiv tiparirii)
'''

'''
Definim o functie folosind cuvantul def (vine de la define, care in romana se traduce "defineste")
O functie are un nume si o lista de parametri
O functie are forma urmatoare

def nume_functie(parametru1, parametru2):
    instructiune1
    instructiune2
    ...
    return valoare
    
La fel ca pentru if, while si for, instructiunile din interiorul functiei sunt aliniate mai la dreapta.
Functia poate returna o valoare, astfel incat noi, cand apelam functia, sa primim acea valoare.
Daca folosim instructiunea "return", returnam valoarea ce urmeaza dupa "return" si apoi se iese automat din functie.
'''


'''
Comentariul de deasupra functiei se numeste documentarea functiei
O functie trebuie documentata prin specificarea a 3 lucruri:
1. Ce face functia
2. Date de intrare (parametri)
3. Date de iesire (valori returnate)

Pentru functia functie_fara_parametri() documentarea functiei arata asa:


Functie ce calculeaza suma 1 + 2
Date intrare: -
Date iesire: c (suma)
'''
def functie_fara_parametri():
    a = 1
    b = 2
    c = a + b
    return c


'''
Functie care verifica daca parametrul introdus este mai mare decat o anumita valoare (4)
Date intrare: parametru
Date iesire: True, daca valoarea parametrului este mai mare decat 4
             False, altfel
'''
def functie_cu_un_parametru(parametru):
    mai_mare = False
    if parametru > 4:
        mai_mare = True
    return mai_mare



'''
Calculeaza suma a doi parametri
Date intrare: parametru1
              parametru2
Date iesire: suma parametrilor
'''
def functie_cu_mai_multi_parametri(parametru1, parametru2):
     suma = parametru1 + parametru2
     return suma


#Functiile nu se vor executa in program daca nu le apelam noi in mod expres.
#Apelam functiile in programul nostru folosind numele lor, astfel:

#Observati ca putem sa dam valori concrete parametrilor cand apelam functia
suma = functie_cu_mai_multi_parametri(2,9)
print("Suma calculata de functia cu mai multi parametri este", suma)

#Putem sa dam functiei ca parametru si o variabila care a fost initializata anterior
nota = 10
promovat = functie_cu_un_parametru(nota)
print("Promovat?", promovat)


#Alte exemple despre cum pot fi apelate functiile

suma_a_b = functie_fara_parametri()
print(suma_a_b)

x = 10
y = 4
suma_a_doi_parametri = functie_cu_mai_multi_parametri(x, y)
print(suma_a_doi_parametri)

mai_mare_decat_patru = functie_cu_un_parametru(20)
print(mai_mare_decat_patru)
