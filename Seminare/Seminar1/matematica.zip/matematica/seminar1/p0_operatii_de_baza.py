#Acesta este un comentariu. Observati ca incepe cu #
#Comentariile NU se executa cand rulam programul. Sunt doar pentru noi, ca sa intelegem mai bine.

"""
Daca vrem sa comentam mai multe linii,
le punem intre 3 ghilimele.
"""

'''
Ghilimelele folosite pentru comentariu pot fi simple ('') sau duble ("").
In comentariul anterior am folosit ghilimele duble.
In comentariul acesta am folosit ghilimele simple.
'''

#Asa tiparim un mesaj in consola
print("Hello!")

#Asa atribuim valori unor variabile
a = 10 #variabila a primeste valoarea 10
b = 2 #variabila b primeste valoarea 2

#Facem operatii cu variabilele noastre
#Observati ca putem da ce nume vrem noi variabilelor si este important sa fie sugestive
#Variabila adunare va stoca rezultatul adunarii dintre a si b
adunare = a+b
print("a + b =", adunare)

scadere = a-b
print("a - b =", scadere)

inmultire = a*b
print("a * b =", inmultire)

#Daca vrem ca variabilele noastre sa fie formate din mai multe cuvinte, le vom lega prin _ (exemplu: ridicare_la_putere)
ridicare_la_putere = a**b
print("a la puterea b =", ridicare_la_putere)

#Putem de asemenea sa incepem fiecare nou cuvant cu litera mare (exemplu: impartireCuZecimale)
#Orice alegem, este important sa ramanem consecventi cu alegerea noastra in tot restul programului
impartireCuZecimale = a/b
print("a / b =", impartireCuZecimale)

#Eu voi ramane consecventa in folosirea numelor de variabile separate prin _
impartire_fara_zecimale = a//b
print("a // b =", impartire_fara_zecimale)

rest = a%b
print("a mod b =", rest)

#Exista cuvinte rezervate de Python anumitor operatii sau instructiuni (de exemplu: if, while, for, def, class, ...)
#Aceste cuvinte NU pot fi folosite ca nume de variabile
#Exemplu: cuvantul "class"
#Daca decomentati linia urmatoare, veti primi o eroare acolo (se va sublinia cu rosu)
#class = 10
#Alte nume de variabile pe care nu le puteti folosi sunt cele care incep cu cifre (ex: 1a, 2cuvant, ...)
#dar este in regula daca cifra nu este prima (cuvant1, inmultire4 sunt nume de variabila corecte)
#Daca decomentati urmatoarele doua linii veti vedea ca primiti din nou eroare (se subliniaza din nou cu rosu) pentru prima linie, dar nu si pentru a doua
#4numar = 2
#numar4=100

#Putem concatena doua siruri de caractere
#un sir de caractere este un text scris intre ghilimele duble ("asa") sau simple ('asa')
sir1 = "primul sir de caractere si "
sir2 = 'al doilea sir de caractere'
sir_de_caractere_concatenat = sir1 + sir2
print(sir_de_caractere_concatenat)
