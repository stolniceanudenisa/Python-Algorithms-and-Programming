'''
Structura repetitiva for
'''


'''
O structura repetitiva de tip for are forma urmatoare

for nume_variabila in range(0, valoare_maxima):
    instructiune1
    instructiune2
    ...

Structura for este o structura repetitiva, asemenea structurii while.
Structura repetitiva for este utila cand vrem sa executam un set de instructiuni de un anumit numar de ori.
Avem control mai mare asupra numarului de repetitii al instructiunilor din cadrul unui for.
Nu vom intra niciodata in bucla infinita (cum se poate intampla la while), deoarece numarul de repetitii este fixat de la inceput.
Daca privim exemplul de mai sus, range(0, valoare_maxima) returneaza secventa de numere de la 0 la valoare_maxima-1.
Pentru fiecare intrare in structura repetitiva for, nume_variabila va lua pe rand valoarea 0, apoi 1, apoi ..., pana la valoare_maxima-1.
Dupa ce nume_variabila ia ultima valoare din secventa (adica valoare_maxima-1), se va iesi automat din for.
In total for-ul se va fi repetat de valoare_maxima ori. (de la 0 la valoare_maxima-1 sunt valoare_maxima numere)
Astfel putem controla numarul de repetitii intr-un for.

Instructiunile instructiune1 si instructiune2 sunt in interiorul structurii repetitive for.
Observati ca sunt aliniate mai la dreapta.
'''

#daca vrem sa repetam un set de operatii de un anumit numar de ori, il putem pune intr-un for
#de exemplu: tiparirea lui i se va repeta de 5 ori
for i in range(0, 5):
    print("acum i este", i)


#alt exemplu: daca vrem sa crestem cu 3 valoarea unei variabile de un anumit numar de ori

#initializam variabila a carei valori o vom creste cu 3
nota = 0
#initalizam variabila care ne va indica de cate ori sa repetam cresterea cu 3 a primei variabile
numar_de_ori = 10

#folosim structura repetitiva for
for i in range(0, numar_de_ori):
    #crestem valoarea variabilei cu 3 de fiecare data cand intram din nou in for
    nota = nota + 3

print("la finalul for-ului, nota are valoarea", nota) #am iesit din for si tiparim valoarea finala