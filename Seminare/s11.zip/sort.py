
#bubble sort
def bubble_sort(list):
    sorted = False
    while(sorted == False):
        sorted = True
        for i in range(len(list)-1):
            if list[i] > list[i+1]:
                list[i],list[i+1] = list[i+1],list[i]
                sorted = False
    return list

#insertion sort
#mutam toate elementele din lista care sunt mai mari decat o cheie
def insertion_sort(list):
    for i in range(1,len(list)):
        key = list[i]
        j = i-1
        while( j>=0 and key <list[j]):
            list[j+1] = list[j]
            j -= 1
        list[j+1] = key
    return list

#selection sort
#gasim cel mai mic element din lista si comparam elementul curent cu el
def selection_sort(list):
    size = len(list)
    for i in range(size):
        min= i
        for j in range(i+1,size):
            if list[j] < list[min]:
                min = j
        list[i],list[min] = list[min],list[i]
    return list

def partition(list, low, high):
    pivot = list[high]
    i = low -1
    for j in range(low,high):
        if list[j] <= pivot:
            i += 1
            list[i],list[j] = list[j], list[i]
    list[i+1], list[high] = list[high],list[i+1]
    return i+1

#quick sort
def quick_sort(list, low, high):
    if low < high:
        pos = partition(list,low, high)
        #sort the left side
        quick_sort(list, low, pos-1)
        #sort right side
        quick_sort(list, pos + 1, high)
    return list


if __name__ == "__main__":
    print("Bubble sort: ", bubble_sort([19, 13, 6, 2, 18, 8]))
    print("Insertion sort: ", insertion_sort([19, 5, 6, 2, 18, 8]))
    print("Selection sort: ", selection_sort([4,7,1,3,9,7]))
    list= [19, 13, 6, 2, 18, 8]
    print("Quick Sort: ", quick_sort(list, 0, len(list)-1))

    