import timeit

### sequential search
# iteram pe toata lista si verificam fiecare element pana gasim cel dorit sau ajungem la finalul listei

def sequential_search(list,item):
    for idx, i in enumerate(list):
        if i == item:
            return True, idx
    return False, -1


### binary search
# impartim lista in doua si cautam in prima parte si in a doua parte
# recursiv sau iterativ
# pentru acest tip de cautare lista ar trebui sa fie sortata

def binary_search_recursiv(list, low, high, item):
    if low <= high:
        mid = (high+low)//2
        if list[mid] == item:
            return mid
        elif list[mid] > item:
            return binary_search_recursiv(list, low, mid - 1, item)
        else:
            return binary_search_recursiv(list, mid+1, high, item)
    else:
        return -1

def binary_search_iterativ(list,item):
    low = 0
    high = len(list)-1
    while low <= high:
        mid = (high + low) //2
        if list[mid] == item:
            return mid
        elif list[mid] < item:
            low = mid + 1
        else:
            high = mid-1
    return -1

if __name__ == "__main__":
    
    list = [11,23,58,31,56,77,43,12,65,19]
    list2 = [1,2,3,4,5,6,7]


    start = timeit.default_timer()
    found, pos = sequential_search(list2,5)
    end = timeit.default_timer()
    print(found, pos)
    print("Secvential: I-a trebuit ", end-start , "secunde pt cautarea")


    start = timeit.default_timer()
    pos = binary_search_recursiv(list2, 0, len(list2)-1, 5)
    end = timeit.default_timer()
    print("Binar Recursiv: I-a trebuit ", end-start , "secunde pt cautarea")
    print(pos)

    start = timeit.default_timer()
    pos = binary_search_iterativ(list2, 5)
    end = timeit.default_timer()
    timeit
    print(pos)
