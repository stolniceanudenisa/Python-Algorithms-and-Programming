


class Suma:
	#atribut de clasa
	numarInstante = 0

	def __init__(self, a =0 , b = 0):
		#atribute de instanta
		self.__primul_numar = a
		self.__al_doilea = b
		Suma.numarInstante += 1
	
	def get_primulNumar(self):
		return self.__primul_numar

	def get_alDoilea(self):
		return self.__al_doilea

	def set_primultNumar(self, a):
		self.__primul_numar = a

	def set_alDoilea(self,b):
		self.__al_doilea = b
	
	def __str__(self):
		return "primul numar e:" + str(self.__primul_numar) + " al doilea numar e: " + str(self.__al_doilea)

	def sumaNumerelor(self):
		return self.__primul_numar + self.__al_doilea
	
	#operator overloading 
	def __add__(self,other):
		return Suma(self.__primul_numar + other.__primul_numar, self.__al_doilea + other.__al_doilea)

	#staticmetod este folosit pentru a marca o functie statics, aceste functii nu au ca prim argument self
	@staticmethod
	def getNumarulInstantelor():
		return Suma.numarInstante

	#simiar cu static dar se primeste un pirm parametru clasa
	@classmethod
	def fromString(cls,input_string):
		lista_numere = input_string.split(",")
		return Suma(int(lista_numere[0]), int(lista_numere[1]))



s0 = Suma()
print(s0.get_primulNumar())
print(s0.get_alDoilea())
s = Suma(5,6)
print(s.get_primulNumar())
print(s.get_alDoilea())
s.set_primultNumar(8)
print(s.get_primulNumar())
print(s.__str__())
print(s.sumaNumerelor())
print(Suma.numarInstante)
s2 = Suma(7,8)
s3 = s+s2
print(s3.__str__())
s4 = Suma.fromString("1,2")
print(s4.get_primulNumar())
print(s4.get_alDoilea())

def teste():
	st = Suma(10,11)
	assert st.get_primulNumar() == 10
	assert st.get_alDoilea() == 11
	st.set_primultNumar(90) 
	assert st.get_primulNumar() == 90
	assert st.sumaNumerelor() == 101

teste()